# :warning: Information
FiveM Script with alot of useful commands/scripts all in one\
Almost everything is customizable in the config.lua\
If you already have one of the scripts, you can easily disable it in the config.lua

# :hammer_and_wrench: Scripts
**Delete vehicle command** - (/dv)\
**Antiswear** - Kicks a player when sending specific messages (You can change these messages in the config.lua)\
**RPCommands** - /twt, /dispatch, /darkweb, /news, /do, /ooc, /me, /show id commands with discord logging\
**Hands up** - Press x to put your hands up\
**Watermark** - Watermark for your server with customizable text\
**Drag command** - /drag command (Drags the closest player)\
**Crouch** - Pressing ctrl makes you crouch\
**Tazer effect** - Gives you an effect when you get tazed\
**No reticle** - Disables the reticle when aiming\
**Damage ragdoll** - Ragdoll when shot\
**Disable combat roll** - Disables players from using the combat roll action while aiming.\
**Finger Point** - Press b to point\
**Server List Uptime** - Adds a server convar with the server uptime\
**No Grip** - When jumping and running, there is an 90% chance of falling (Customizable)\
**Anti air control** - Disable air control with vehicles\
**PVP Enabled** - Enables PVP on your server\
**Delallveh** - Delete all vehicles on the server\
**AFK Kick** - Kick AFK players\
**Never Wanted** - Disable wanted level and emergency services\
**Remove Parked Vehicles** - Removes all parked vehicles\
**Auto Messages** - Sends the configurable messages to the player, every x minutes.

# :inbox_tray: Download
[Download via Github](https://github.com/Swqppingg/RPCore)


# :gear:  How to install
Add the **RPCore** folder to your FiveM resources directory.\
Edit your server.cfg and add "ensure **RPCore** "\
Edit config.lua to be customized for your server.



# :wrench: Support
Open an issue or join my discord server for support
https://discord.gg/X3Mb74Phnq

---------------------------------------------------

![Screenshot](https://i.imgur.com/GU3LSL2.png)



**Todo:**
- [ ] Cuff command
- [x] delallveh command
- [ ] Emotes
- [ ] Ingame Logs
- [ ] /freeze command
- [ ] Discord Rich Presence
- [x] afk kick
- [x] move discord webhook to server.lua
