fx_version 'cerulean'
game 'gta5'
description 'Roleplay Core'

client_script 'client.lua'
client_script 'entityiter.lua'
server_script 'server.lua'
shared_script 'config.lua'
