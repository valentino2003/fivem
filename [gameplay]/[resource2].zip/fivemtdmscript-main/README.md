# TDM Script for Fivem
## Team Deathmatch Script for FiveM (Lua)
### Use /rojo /azul 
to get equipped as a red/blue team player!
