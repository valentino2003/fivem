fx_version 'cerulean'
game 'gta5'

author 'Pol Galvez'
description 'PvP plugin trd'
version '1.0.0'

client_script 'client.lua'

server_script 'server.lua'
