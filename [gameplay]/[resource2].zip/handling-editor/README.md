# HandlingEditor
Live handling editor for FiveM

Start script, then type command /handling [handling name] to open menu (e.g. /handling zentorno). You have to be inside vehicle to use command, after typing /handling command you can open menu with left shift.
When you finish customizing your handling you can copy it to the clipboard (by clicking on Export), and paste it into handling.meta file (from fMass to nMonetaryValue);)

**Preview**
![image](https://user-images.githubusercontent.com/40892034/229254038-847c1493-f761-479c-9b5d-3b3279abeb91.png)

[PL] Wiele poradników dla osób zaczynających przygodę z developerką lub kontynuujących ją znajdziesz na https://discord.gg/babiczind
